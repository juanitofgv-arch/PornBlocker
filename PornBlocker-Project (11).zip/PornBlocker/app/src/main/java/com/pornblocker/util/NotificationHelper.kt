package com.pornblocker.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.pornblocker.R

object NotificationHelper {
    
    private const val CHANNEL_BLOCK_ALERT = "block_alert_channel"
    private const val CHANNEL_MONITORING = "monitoring_channel"
    
    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            // Canal para alertas de bloqueo
            val blockChannel = NotificationChannel(
                CHANNEL_BLOCK_ALERT,
                "Alertas de Bloqueo",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notificaciones cuando se detecta y bloquea contenido prohibido"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(blockChannel)
            
            // Canal para servicio de monitoreo
            val monitoringChannel = NotificationChannel(
                CHANNEL_MONITORING,
                context.getString(R.string.foreground_service_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.foreground_service_description)
                setShowBadge(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_SECRET
            }
            manager.createNotificationChannel(monitoringChannel)
        }
    }
    
    fun showBlockAlert(context: Context, reason: String) {
        val notification = NotificationCompat.Builder(context, CHANNEL_BLOCK_ALERT)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("🚫 Contenido Bloqueado")
            .setContentText("Se detectó: $reason. Navegador cerrado y caché borrada.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "Se detectó contenido prohibido: $reason\n\n" +
                "Acciones realizadas:\n" +
                "✅ Navegador cerrado forzosamente\n" +
                "✅ Caché y datos borrados\n" +
                "✅ Redirección activada (si está configurada)"
            ))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_WARNING)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
        
        NotificationManagerCompat.from(context).notify(
            "block_alert", 
            (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), 
            notification
        )
    }
    
    fun showProtectionStatus(context: Context, isActive: Boolean) {
        val title = if (isActive) "✅ Protección Activada" else "❌ Protección Desactivada"
        val text = if (isActive) 
            "El bloqueo de contenido adulto está ACTIVO" 
        else 
            "El bloqueo está INACTIVO. Pulsa para activar."
        
        val notification = NotificationCompat.Builder(context, CHANNEL_MONITORING)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setOngoing(isActive)
            .setOnlyAlertOnce(true)
            .build()
        
        NotificationManagerCompat.from(context).notify(1002, notification)
    }
}