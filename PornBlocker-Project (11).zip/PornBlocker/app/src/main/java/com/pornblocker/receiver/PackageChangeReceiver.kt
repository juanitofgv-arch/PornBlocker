package com.pornblocker.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.pornblocker.root.RootHelper

class PackageChangeReceiver : BroadcastReceiver() {
    
    private const val TAG = "PackageChangeReceiver"

    override fun onReceive(context: Context?, intent: Intent?) {
        val action = intent?.action
        val packageName = intent?.data?.schemeSpecificPart
        
        if (packageName == null) return
        
        when (action) {
            Intent.ACTION_PACKAGE_REMOVED -> {
                Log.d(TAG, "Package removed: $packageName")
                // Si se desinstala nuestra app, no hay nada que hacer
                // Si se desinstala un navegador, actualizar lista
                if (isBrowserPackage(packageName)) {
                    RootHelper.getInstalledBrowserPackages(context!!)
                }
            }
            Intent.ACTION_PACKAGE_ADDED, Intent.ACTION_PACKAGE_REPLACED -> {
                Log.d(TAG, "Package added/replaced: $packageName")
                // Actualizar lista de navegadores conocidos
                if (isBrowserPackage(packageName)) {
                    RootHelper.getInstalledBrowserPackages(context!!)
                }
            }
        }
    }

    private fun isBrowserPackage(packageName: String): Boolean {
        return packageName.contains("browser", ignoreCase = true) ||
               packageName.contains("chrome", ignoreCase = true) ||
               packageName.contains("firefox", ignoreCase = true) ||
               packageName.contains("opera", ignoreCase = true) ||
               packageName.contains("ucbrowser", ignoreCase = true) ||
               packageName.contains("brave", ignoreCase = true) ||
               packageName.contains("duckduckgo", ignoreCase = true) ||
               packageName.contains("kiwi", ignoreCase = true) ||
               packageName.contains("samsung.*browser", ignoreCase = true)
    }
}