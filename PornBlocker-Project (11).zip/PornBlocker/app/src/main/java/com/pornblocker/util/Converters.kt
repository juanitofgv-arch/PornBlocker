package com.pornblocker.util

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type

class Converters {
    private val gson = Gson()
    private val listType: Type = TypeToken.getParameterized(List::class.java, String::class.java).type

    @TypeConverter
    fun fromStringList(value: String?): List<String> {
        return if (value.isNullOrEmpty()) emptyList() else gson.fromJson(value, listType)
    }

    @TypeConverter
    fun toStringList(list: List<String>?): String {
        return if (list.isNullOrEmpty()) "" else gson.toJson(list)
    }
}