package com.pornblocker.di

import android.content.Context
import com.pornblocker.model.AppDatabase
import com.pornblocker.model.BlockConfigDao
import com.pornblocker.model.ConfigRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getDatabase(context)
    }

    @Provides
    @Singleton
    fun provideBlockConfigDao(database: AppDatabase): BlockConfigDao {
        return database.blockConfigDao()
    }

    @Provides
    @Singleton
    fun provideConfigRepository(dao: BlockConfigDao, @ApplicationContext context: Context): ConfigRepository {
        return ConfigRepository(dao)
    }
}