package com.pornblocker.model

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockConfigDao {
    @Query("SELECT * FROM block_config WHERE id = 1")
    fun getConfig(): Flow<BlockConfig?>

    @Query("SELECT * FROM block_config WHERE id = 1")
    suspend fun getConfigSync(): BlockConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: BlockConfig)

    @Update
    suspend fun updateConfig(config: BlockConfig)

    @Query("INSERT INTO detection_log (browserPackage, detectedContent, actionTaken, wasRedirected) VALUES (:browserPackage, :detectedContent, :actionTaken, :wasRedirected)")
    suspend fun logDetection(browserPackage: String, detectedContent: String, actionTaken: String, wasRedirected: Boolean)

    @Query("SELECT * FROM detection_log ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentLogs(limit: Int): List<DetectionLog>

    @Query("DELETE FROM detection_log WHERE timestamp < :beforeTimestamp")
    suspend fun deleteOldLogs(beforeTimestamp: Long)
}