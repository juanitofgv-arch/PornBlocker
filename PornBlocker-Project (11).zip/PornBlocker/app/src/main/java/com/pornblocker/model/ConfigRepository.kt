package com.pornblocker.model

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.map
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ConfigRepository(private val dao: BlockConfigDao) {

    // Default blacklist values
    private val defaultWords = "porno\nporn\nxxx\nsexo\nsex\nadult\nadulto\nerotico\nerotica\ndesnudo\ndesnuda\npornhub\nxvideos\nxhamster\nredtube\nyouporn\nsexo gratis\nvideos porno\npeliculas porno\nchat sexo\nwebcam sexo\nputas\nprostitutas\nescorts\nmasajes eroticos\ncontactos sexo\nsexo casual\ncitas sexo\namateur\ncasero\nhentai\nrule34\nonlyfans\nfansly\nmanyvids\nchaturbate\nstripchat\nlivejasmin\nbongacams\ncam4\nmyfreecams\ncamgirls\ncamboys\nwebcam porn\nsex cam\nlive sex\nfree cams\nadult cam\nxxx cams\nporn cams\nsex chat\nadult chat\nsex dating\nadult dating\nhookup\ncasual sex\none night stand\nfriends with benefits\nfwb\nnsa\nno strings attached\nswingers\nswapping\nthreesome\ngangbang\norgy\nbukkake\ncreampie\nanal\noral\nblowjob\nfellatio\ncunnilingus\nrimming\nfisting\ndouble penetration\ndp\nbdsm\nbondage\ndomination\nsubmission\nsadism\nmasochism\nfetish\nkink\nlatex\nleather\npvc\nfeet\nfootjob\npantyhose\nstockings\nlingerie\ncrossdresser\nshemale\ntranny\nladyboy\ntransgender\ntranssexual\nts\ntgirl\nsissy\nfeminization\nchastity\ncuckold\nhotwife\ncuckquean\nvoyeur\nexhibitionist\npublic sex\noutdoor sex\ncar sex\nbeach sex\npark sex\ntoilet sex\nbathroom sex\nshower sex\npool sex\nmassage porn\nnuru\nnurumassage\nhappy ending\ntantric\ntantra\nerotic massage\nsensual massage\nbody to body\nfull service\nescort service\ncall girl\ncall boy\ngigolo\nrentboy\nrentgirl\nsugar baby\nsugar daddy\nsugar mama\narrangement\npay for play\np4p\ntransactional sex\nsex work\nprostitution\nwhore\nhooker\nstreetwalker\nbrothel\nred light district"

    private val defaultSites = "pornhub.com\nxvideos.com\nxhamster.com\nredtube.com\nyouporn.com\nxnxx.com\nspankbang.com\nporn.com\ntube8.com\nbeeg.com\nhqporner.com\neporner.com\npornhd.com\nporntrex.com\npornktube.com\npornzog.com\npornwhite.com\npornid.xxx\npornve.com\nporngo.com\npornrabbit.com\npornstar.com\nporntube.com\npornhubpremium.com"

    val configFlow = dao.getConfig()

    suspend fun getConfig(): BlockConfig = withContext(Dispatchers.IO) {
        dao.getConfigSync() ?: BlockConfig(
            blockedWords = defaultWords,
            blockedSites = defaultSites
        ).also { dao.insertConfig(it) }
    }

    suspend fun updateConfig(
        blockedWords: String? = null,
        blockedSites: String? = null,
        redirectPackageName: String? = null,
        isRedirectEnabled: Boolean? = null,
        isProtectionActive: Boolean? = null
    ) = withContext(Dispatchers.IO) {
        val current = getConfig()
        val updated = current.copy(
            blockedWords = blockedWords ?: current.blockedWords,
            blockedSites = blockedSites ?: current.blockedSites,
            redirectPackageName = redirectPackageName ?: current.redirectPackageName,
            isRedirectEnabled = isRedirectEnabled ?: current.isRedirectEnabled,
            isProtectionActive = isProtectionActive ?: current.isProtectionActive,
            lastUpdated = System.currentTimeMillis()
        )
        dao.updateConfig(updated)
    }

    suspend fun resetToDefaults() = withContext(Dispatchers.IO) {
        val defaults = BlockConfig(
            blockedWords = defaultWords,
            blockedSites = defaultSites
        )
        dao.updateConfig(defaults)
    }

    suspend fun logDetection(browserPackage: String, detectedContent: String, actionTaken: String, wasRedirected: Boolean) = 
        withContext(Dispatchers.IO) {
            dao.logDetection(browserPackage, detectedContent, actionTaken, wasRedirected)
        }

    suspend fun getRecentLogs(limit: Int = 50): List<DetectionLog> = 
        withContext(Dispatchers.IO) {
            dao.getRecentLogs(limit)
        }
}

object ConfigRepositoryFactory {
    fun create(context: Context): ConfigRepository {
        val database = AppDatabase.getDatabase(context)
        return ConfigRepository(database.blockConfigDao())
    }
}