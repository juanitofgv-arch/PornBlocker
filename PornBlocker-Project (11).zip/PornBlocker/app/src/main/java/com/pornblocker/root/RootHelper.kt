package com.pornblocker.root

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

object RootHelper {
    private const val TAG = "RootHelper"
    private var _hasRoot: Boolean? = null

    /** Verifica si el dispositivo tiene acceso root */
    fun hasRootAccess(): Boolean {
        if (_hasRoot != null) return _hasRoot!!
        
        return try {
            val process = Runtime.getRuntime().exec("su -c id")
            val output = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val exitValue = process.waitFor()
            val result = exitValue == 0 && output.contains("uid=0")
            _hasRoot = result
            Log.d(TAG, "Root access: $result")
            result
        } catch (e: Exception) {
            Log.e(TAG, "Error checking root", e)
            _hasRoot = false
            false
        }
    }

    /** Ejecuta un comando como root */
    @Suppress("UNUSED_PARAMETER")
    fun executeRootCommand(command: String): CommandResult {
        return try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            
            os.writeBytes("$command\n")
            os.writeBytes("exit\n")
            os.flush()
            
            val output = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val error = BufferedReader(InputStreamReader(process.errorStream)).readText()
            val exitValue = process.waitFor()
            
            CommandResult(exitValue == 0, output, error, exitValue)
        } catch (e: Exception) {
            Log.e(TAG, "Error executing root command: $command", e)
            CommandResult(false, "", e.message ?: "Unknown error", -1)
        }
    }

    /** Ejecuta múltiples comandos como root */
    fun executeRootCommands(commands: List<String>): List<CommandResult> {
        return try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            
            for (command in commands) {
                os.writeBytes("$command\n")
            }
            os.writeBytes("exit\n")
            os.flush()
            
            val output = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val error = BufferedReader(InputStreamReader(process.errorStream)).readText()
            val exitValue = process.waitFor()
            
            List(commands.size) { CommandResult(exitValue == 0, output, error, exitValue) }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing root commands", e)
            commands.map { CommandResult(false, "", e.message ?: "Unknown error", -1) }
        }
    }

    /** Cierra una aplicación por paquete */
    fun killApp(packageName: String): Boolean {
        val commands = listOf(
            "am kill $packageName",
            "am force-stop $packageName",
            "pkill -f $packageName"
        )
        val results = executeRootCommands(commands)
        return results.any { it.success }
    }

    /** Borra la caché y datos de una aplicación */
    fun clearAppCacheAndData(packageName: String): Boolean {
        val commands = listOf(
            "pm clear $packageName",
            "rm -rf /data/data/$packageName/cache/*",
            "rm -rf /data/data/$packageName/code_cache/*",
            "rm -rf /data/user/0/$packageName/cache/*",
            "rm -rf /data/user/0/$packageName/code_cache/*"
        )
        val results = executeRootCommands(commands)
        return results.any { it.success }
    }

    /** Obtiene la lista de paquetes de navegadores instalados */
    fun getInstalledBrowserPackages(context: Context): List<String> {
        val knownBrowsers = listOf(
            "com.android.chrome",
            "com.google.android.apps.chrome",
            "org.mozilla.firefox",
            "com.microsoft.emmx",
            "com.opera.browser",
            "com.opera.mini.native",
            "com.uc.browser",
            "com.UCMobile",
            "com.samsung.android.app.sbrowser",
            "com.brave.browser",
            "com.duckduckgo.mobile.android",
            "org.mozilla.focus",
            "com.kiwibrowser.browser",
            "com.viber.voip",
            "com.sec.android.app.sbrowser",
            "com.android.browser"
        )
        
        val pm = context.packageManager
        return knownBrowsers.filter { pm.getLaunchIntentForPackage(it) != null }
    }

    /** Verifica si es Device Owner */
    fun isDeviceOwner(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
        return dpm.isDeviceOwnerApp(context.packageName)
    }

    data class CommandResult(
        val success: Boolean,
        val output: String,
        val error: String,
        val exitCode: Int
    )
}