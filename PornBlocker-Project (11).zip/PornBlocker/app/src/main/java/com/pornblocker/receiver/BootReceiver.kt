package com.pornblocker.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.pornblocker.model.AppDatabase
import com.pornblocker.model.BlockConfig
import com.pornblocker.service.MonitoringForegroundService
import com.pornblocker.service.DnsFilterVpnService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    
    private const val TAG = "BootReceiver"

    override fun onReceive(context: Context?, intent: Intent?) {
        val action = intent?.action
        if (action == Intent.ACTION_BOOT_COMPLETED || 
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON") {
            
            Log.d(TAG, "Boot completed, restoring protection")
            context?.let { ctx ->
                CoroutineScope(Dispatchers.IO).launch {
                    val db = AppDatabase.getDatabase(ctx)
                    val config = db.blockConfigDao().getConfigSync()
                    
                    if (config?.isProtectionActive == true) {
                        // Reactivar servicios
                        MonitoringForegroundService.startService(ctx)
                        
                        // Preparar VPN (requiere interacción del usuario en primer inicio)
                        // DnsFilterVpnService.prepareVpn(ctx)?.let { vpnIntent ->
                        //     ctx.startActivity(vpnIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        // }
                        
                        Log.d(TAG, "Protection restored after boot")
                    }
                }
            }
        }
    }
}