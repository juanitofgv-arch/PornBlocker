package com.pornblocker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PornBlockerApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Inicialización global si es necesaria
    }
}