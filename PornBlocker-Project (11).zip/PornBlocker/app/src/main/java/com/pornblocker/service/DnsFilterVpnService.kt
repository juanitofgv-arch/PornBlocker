package com.pornblocker.service

import android.app.Service
import android.content.Intent
import android.net.VpnService
import android.os.IBinder
import android.util.Log
import com.pornblocker.model.AppDatabase
import com.pornblocker.model.BlockConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import java.nio.channels.FileChannel
import java.util.concurrent.ConcurrentHashMap

class DnsFilterVpnService : VpnService() {
    private const val TAG = "DnsFilterVpnService"
    private var vpnInterface: android.net.VpnService.Builder? = null
    private var fileDescriptor: android.os.ParcelFileDescriptor? = null
    private var inputStream: FileInputStream? = null
    private var outputStream: FileOutputStream? = null
    private var isRunning = false
    private val blockedDomains = ConcurrentHashMap<String, Boolean>()
    private val scope = CoroutineScope(Dispatchers.IO)
    private var currentConfig: BlockConfig? = null

    override fun onCreate() {
        super.onCreate()
        loadBlockedDomains()
    }

    private fun loadBlockedDomains() {
        scope.launch {
            val db = AppDatabase.getDatabase(this@DnsFilterVpnService)
            currentConfig = db.blockConfigDao().getConfigSync()
            currentConfig?.let { config ->
                blockedDomains.clear()
                config.blockedSites.split("\n")
                    .map { it.trim().lowercase() }
                    .filter { it.isNotEmpty() }
                    .forEach { blockedDomains[it] = true }
                Log.d(TAG, "Loaded ${blockedDomains.size} blocked domains")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            startVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        try {
            val builder = Builder()
                .setSession("DnsFilterVpn")
                .addAddress("10.0.0.1", 24)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .addRoute("0.0.0.0", 0)
            
            // Excluir la propia app del VPN
            try {
                builder.addDisallowedApplication(packageName)
            } catch (e: Exception) {
                Log.w(TAG, "Could not exclude self from VPN", e)
            }

            fileDescriptor = builder.establish()
            
            if (fileDescriptor != null) {
                inputStream = FileInputStream(fileDescriptor!!.fileDescriptor)
                outputStream = FileOutputStream(fileDescriptor!!.fileDescriptor)
                isRunning = true
                
                // Iniciar loop de procesamiento de paquetes
                scope.launch { processPackets() }
                
                Log.d(TAG, "VPN started successfully")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting VPN", e)
        }
    }

    private suspend fun processPackets() {
        val packet = ByteBuffer.allocate(32767)
        val channel = DatagramChannel.open()
        
        try {
            channel.socket.bind(InetSocketAddress(53))
            channel.configureBlocking(false)
            
            while (isRunning && !Thread.interrupted()) {
                packet.clear()
                
                // Leer paquete del túnel VPN
                val inputChannel = inputStream?.channel
                if (inputChannel != null) {
                    val read = inputChannel.read(packet)
                    if (read > 0) {
                        packet.flip()
                        val processedPacket = processDnsPacket(packet)
                        if (processedPacket != null) {
                            outputStream?.channel?.write(processedPacket)
                        }
                    }
                }
                
                // Pequeña pausa para no consumir 100% CPU
                Thread.sleep(1)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in packet processing loop", e)
        } finally {
            channel.close()
        }
    }

    private fun processDnsPacket(buffer: ByteBuffer): ByteBuffer? {
        // Parsing básico de paquete DNS
        // En una implementación real, se usaría una librería como dnsjava
        // Aquí simplificamos: si es consulta a dominio bloqueado, respondemos NXDOMAIN
        
        try {
            // Verificar si es paquete DNS (puerto 53)
            // Extraer dominio de la consulta
            // Si está en blockedDomains, retornar respuesta NXDOMAIN
            // Sino, forward a DNS real
            
            // Implementación simplificada - en producción usar librería DNS apropiada
            return buffer
        } catch (e: Exception) {
            Log.e(TAG, "Error processing DNS packet", e)
            return buffer
        }
    }

    fun updateBlockedDomains(config: BlockConfig) {
        currentConfig = config
        blockedDomains.clear()
        config.blockedSites.split("\n")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .forEach { blockedDomains[it] = true }
        Log.d(TAG, "Updated blocked domains: ${blockedDomains.size}")
    }

    override fun onDestroy() {
        isRunning = false
        try {
            inputStream?.close()
            outputStream?.close()
            fileDescriptor?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing VPN", e)
        }
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = null

    companion object {
        fun prepareVpn(context: android.content.Context): Intent? {
            return VpnService.prepare(context)
        }
    }
}