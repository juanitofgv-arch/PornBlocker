package com.pornblocker.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.pornblocker.util.Converters

@Entity(tableName = "block_config")
data class BlockConfig(
    @PrimaryKey val id: Int = 1,
    val blockedWords: String = "",
    val blockedSites: String = "",
    val redirectPackageName: String = "",
    val isRedirectEnabled: Boolean = false,
    val isProtectionActive: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "detection_log")
data class DetectionLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val browserPackage: String,
    val detectedContent: String,
    val actionTaken: String,
    val wasRedirected: Boolean
)

@TypeConverters(Converters::class)
data class BlacklistData(
    val words: List<String> = emptyList(),
    val sites: List<String> = emptyList()
)