# ProGuard rules for PornBlocker

# Keep Hilt generated classes
-keep class dagger.hilt.** { *; }
-keep class com.pornblocker.** { *; }

# Keep Room entities and DAOs
-keep class com.pornblocker.model.** { *; }

# Keep Parcelable implementations
-keep class * implements android.os.Parcelable { *; }

# Keep enum values
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Keep annotation processors
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

# Keep JSON serialization (Gson)
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# Keep Kotlin metadata
-keep class kotlin.Metadata { *; }

# Keep Coroutines
-keepclassmembers class kotlinx.coroutines.** { *; }

# Suppress warnings for unused classes
-dontwarn kotlinx.coroutines.**
-dontwarn androidx.room.**
-dontwarn dagger.hilt.**
-dontwarn com.google.dagger.**