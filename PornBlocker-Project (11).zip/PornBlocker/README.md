# PornBlocker - Aplicación de Bloqueo de Contenido Adulto

Aplicación Android para bloquear contenido pornográfico en todos los navegadores con lista negra personalizable.

## Características Principales

1. **Bloqueo Universal**: Funciona en TODOS los navegadores (Chrome, Firefox, Opera, Brave, Samsung Browser, etc.)
2. **Lista Negra Personalizable**: Palabras y sitios web configurables por el usuario
3. **Protección Irreversible**: Una vez activada, no se puede desactivar desde la app (solo desinstalando)
4. **Acciones Automáticas al Detectar Contenido**:
   - Cierra el navegador inmediatamente
   - Borra la caché y datos del navegador (equivalente a "Forzar detención" + "Borrar almacenamiento")
   - Abre una app de redirección elegida por el usuario (opcional)
5. **Filtrado DNS a Nivel de Red**: VPN local que bloquea dominios pornográficos conocidos
6. **Monitoreo en Tiempo Real**: Servicio de accesibilidad + Foreground Service

## Requisitos

- **Android 7.0 (API 24) o superior**
- **Acceso Root** O **Device Owner** (para cerrar apps y borrar caché de otros paquetes)
- Permisos especiales:
  - Administrador de Dispositivo
  - Servicio de Accesibilidad
  - VPN Local
  - Estadísticas de Uso
  - Dibujar sobre otras apps

## Compilación

### Opción 1: Android Studio (Recomendado)
1. Abre el proyecto en Android Studio
2. Espera a que Gradle sincronice
3. Build > Build Bundle(s) / APK(s) > Build APK(s)

### Opción 2: Línea de Comandos
```bash
cd PornBlocker
./gradlew assembleDebug
# El APK estará en app/build/outputs/apk/debug/app-debug.apk
```

## Instalación y Configuración

1. **Instala el APK** en el dispositivo objetivo
2. **Abre la app** y pulsa "ACTIVAR PROTECCIÓN"
3. **Concede todos los permisos solicitados**:
   - Administrador de Dispositivo (OBLIGATORIO)
   - Servicio de Accesibilidad (OBLIGATORIO)
   - VPN Local (OBLIGATORIO)
   - Estadísticas de Uso (OBLIGATORIO)
   - Superposición (OBLIGATORIO)
4. **Configura la lista negra** en Ajustes si deseas personalizarla
5. **Opcional**: Selecciona una app de redirección (ej: app de meditación, Biblia, app productividad)

## Desinstalación

Para desactivar la protección completamente:
1. Ve a **Ajustes > Aplicaciones > PornBlocker**
2. Pulsa **Desinstalar**
3. La app se eliminará junto con toda su configuración y protección

## Arquitectura Técnica

```
┌─────────────────────────────────────────────────────────┐
│                    PornBlocker App                      │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │
│  │ Accessibility│  │   VPN/DNS   │  │  Foreground     │  │
│  │   Service    │  │   Filter    │  │   Service       │  │
│  └──────┬──────┘  └──────┬──────┘  └────────┬────────┘  │
│         │                │                   │            │
│         └────────────────┼───────────────────┘            │
│                          ▼                                 │
│              ┌─────────────────────┐                       │
│              │   Root Helper       │                       │
│              │  (killApp, clear    │                       │
│              │   Cache, Data)      │                       │
│              └──────────┬──────────┘                       │
│                         │                                   │
│              ┌──────────▼──────────┐                       │
│              │   Room Database     │                       │
│              │  (Config + Logs)    │                       │
│              └─────────────────────┘                       │
└─────────────────────────────────────────────────────────┘
```

### Componentes Clave

1. **BrowserMonitoringAccessibilityService**: Detecta contenido en navegadores mediante eventos de accesibilidad
2. **DnsFilterVpnService**: Filtra dominios a nivel de red usando VPN local
3. **MonitoringForegroundService**: Mantiene el monitoreo activo y verifica integridad
4. **AdminReceiver**: Device Admin que previene desactivación
5. **RootHelper**: Ejecuta comandos shell como root para control total

## Lista Negra Predeterminada

Incluye 500+ palabras y 100+ dominios pornográficos conocidos en múltiples idiomas (español, inglés, etc.).

## Personalización

En **Ajustes** puedes:
- Agregar/quitar palabras prohibidas
- Agregar/quitar dominios bloqueados
- Configurar app de redirección
- Activar/desactivar redirección automática

## Seguridad y Privacidad

- **Sin internet**: La app no envía datos a servidores externos
- **Datos locales**: Todo se guarda en Room Database encriptada
- **Sin analytics**: No hay tracking ni telemetría
- **Código abierto**: Auditable completamente

## Limitaciones Conocidas

1. **Sin Root/Device Owner**: No puede cerrar apps ni borrar caché de otros paquetes
2. **Navegadores en modo incógnito**: Algunos navegadores ocultan contenido en modo privado
3. **Apps WebView**: Apps que usan WebView interno (Twitter, Facebook, etc.) requieren detección adicional
4. **VPN del sistema**: Si hay otra VPN activa, la nuestra puede no funcionar correctamente

## Solución de Problemas

### "La app no bloquea nada"
- Verifica que el Servicio de Accesibilidad esté ACTIVO (Ajustes > Accesibilidad > PornBlocker)
- Verifica que la VPN esté CONECTADA (aparece llave en barra de estado)
- Verifica que tengas Root/Device Owner funcionando

### "No se puede activar Administrador de Dispositivo"
- Algunas ROMs requieren ir a Ajustes > Seguridad > Administradores de dispositivo manualmente

### "La VPN se desconecta sola"
- Añade la app a la lista de "No optimizar batería" (Ajustes > Batería > Optimización)

## Licencia

Proyecto privado para uso personal. No redistribuir sin autorización.

## Soporte

Para problemas técnicos, revisa los logs con:
```bash
adb logcat | grep -E "(PornBlocker|BrowserMonitor|DnsFilter|Monitoring)"
```