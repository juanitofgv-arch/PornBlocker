package com.pornblocker.ui

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.pornblocker.R
import com.pornblocker.databinding.ActivityMainBinding
import com.pornblocker.model.AppDatabase
import com.pornblocker.model.BlockConfig
import com.pornblocker.receiver.AdminReceiver
import com.pornblocker.root.RootHelper
import com.pornblocker.service.BrowserMonitoringAccessibilityService
import com.pornblocker.service.DnsFilterVpnService
import com.pornblocker.service.MonitoringForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    
    private var binding: ActivityMainBinding? = null
    private lateinit var dpm: DevicePolicyManager
    private lateinit var adminComponent: ComponentName
    private var currentConfig: BlockConfig? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        
        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, AdminReceiver::class.java)
        
        setupUI()
        loadConfig()
    }

    private fun setupUI() {
        binding?.mainActionButton?.setOnClickListener { handleMainAction() }
        binding?.settingsButton?.setOnClickListener { openSettings() }
        binding?.testButton?.setOnClickListener { testBlock() }
    }

    private fun loadConfig() {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@MainActivity)
            currentConfig = db.blockConfigDao().getConfigSync()
            updateUI()
        }
    }

    private fun updateUI() {
        runOnUiThread {
            val isActive = currentConfig?.isProtectionActive == true
            val isAdmin = dpm.isAdminActive(adminComponent)
            
            binding?.statusText?.text = if (isActive) getString(R.string.status_active) else getString(R.string.status_inactive)
            binding?.statusText?.setTextColor(if (isActive) getColor(R.color.green_500) else getColor(R.color.red_500))
            binding?.statusDescription?.text = if (isActive) "La protección está activa y no se puede desactivar" else "La protección está desactivada"
            
            binding?.mainActionButton?.text = if (isActive) getString(R.string.deactivate_button) else getString(R.string.activate_button)
            binding?.mainActionButton?.backgroundTintList = if (isActive) 
                android.content.res.ColorStateList.valueOf(getColor(R.color.red_500)) 
            else 
                android.content.res.ColorStateList.valueOf(getColor(R.color.green_500))
            
            binding?.testButton?.visibility = if (isActive) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun handleMainAction() {
        val isActive = currentConfig?.isProtectionActive == true
        
        if (isActive) {
            // Mostrar diálogo explicando que no se puede desactivar desde la app
            MaterialAlertDialogBuilder(this)
                .setTitle("Protección Activa")
                .setMessage("La protección no se puede desactivar desde la aplicación. Para desactivarla, debes desinstalar la app desde Ajustes > Aplicaciones.")
                .setPositiveButton("Ir a Desinstalar") { _, _ ->
                    openUninstallScreen()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } else {
            // Activar protección - requiere permisos
            startActivationProcess()
        }
    }

    private fun startActivationProcess() {
        val checks = mutableListOf<String>()
        
        // 1. Admin de dispositivo
        if (!dpm.isAdminActive(adminComponent)) {
            checks.add("Administrador de dispositivo")
        }
        
        // 2. Servicio de accesibilidad
        if (!BrowserMonitoringAccessibilityService.isServiceEnabled(this)) {
            checks.add("Servicio de accesibilidad")
        }
        
        // 3. VPN
        // La VPN se prepara luego
        
        // 4. Estadísticas de uso
        if (!hasUsageStatsPermission()) {
            checks.add("Estadísticas de uso")
        }
        
        // 5. Superposición
        if (!Settings.canDrawOverlays(this)) {
            checks.add("Permiso de superposición")
        }
        
        // 6. Root (opcional pero recomendado)
        if (!RootHelper.hasRootAccess() && !RootHelper.isDeviceOwner(this)) {
            checks.add("Acceso Root (recomendado)")
        }
        
        if (checks.isNotEmpty()) {
            showPermissionDialog(checks)
        } else {
            activateProtection()
        }
    }

    private fun showPermissionDialog(checks: List<String>) {
        val message = "Para activar la protección se necesitan los siguientes permisos:\n\n• ${checks.joinToString("\n• ")}"
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Permisos Requeridos")
            .setMessage(message)
            .setPositiveButton("Configurar Ahora") { _, _ ->
                openPermissionScreens(checks)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun openPermissionScreens(checks: List<String>) {
        for (check in checks) {
            when (check) {
                "Administrador de dispositivo" -> {
                    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                    intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.require_admin_message))
                    startActivityForResult(intent, 1001)
                }
                "Servicio de accesibilidad" -> {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    startActivity(intent)
                }
                "Estadísticas de uso" -> {
                    val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                    startActivity(intent)
                }
                "Permiso de superposición" -> {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(intent)
                }
                "Acceso Root (recomendado)" -> {
                    Toast.makeText(this, "Se requiere root para funcionalidad completa (cerrar apps, borrar caché)", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun activateProtection() {
        // Preparar VPN
        DnsFilterVpnService.prepareVpn(this)?.let { vpnIntent ->
            startActivityForResult(vpnIntent, 1002)
            return
        }
        
        // Si no se necesita preparación de VPN, activar directamente
        doActivateProtection()
    }

    private fun doActivateProtection() {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@MainActivity)
            val config = db.blockConfigDao().getConfigSync() ?: BlockConfig()
            val updated = config.copy(isProtectionActive = true)
            db.blockConfigDao().updateConfig(updated)
            
            runOnUiThread {
                currentConfig = updated
                updateUI()
                Toast.makeText(this@MainActivity, "Protección activada correctamente", Toast.LENGTH_LONG).show()
                MonitoringForegroundService.startService(this@MainActivity)
            }
        }
    }

    private fun openSettings() {
        val intent = Intent(this, SettingsActivity::class.java)
        startActivity(intent)
    }

    private fun testBlock() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Probar Bloqueo")
            .setMessage("Esto simulará una detección de contenido prohibido. Se cerrará el navegador de prueba (si hay uno abierto) y se borrará su caché.")
            .setPositiveButton("Probar") { _, _ ->
                simulateBlock()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun simulateBlock() {
        val browsers = RootHelper.getInstalledBrowserPackages(this)
        if (browsers.isNotEmpty()) {
            val testBrowser = browsers[0]
            lifecycleScope.launch(Dispatchers.IO) {
                val killed = RootHelper.killApp(testBrowser)
                val cleared = RootHelper.clearAppCacheAndData(testBrowser)
                
                runOnUiThread {
                    Toast.makeText(this@MainActivity, 
                        "Prueba: Kill=$killed, Clear=$cleared en $testBrowser", 
                        Toast.LENGTH_LONG).show()
                }
            }
        } else {
            Toast.makeText(this, "No hay navegadores instalados para probar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openUninstallScreen() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        startActivity(intent)
    }

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = appOps.checkOpNoThrow(
            android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            1001 -> { // Admin result
                if (resultCode == Activity.RESULT_OK) {
                    checkVpnAndActivate()
                }
            }
            1002 -> { // VPN result
                if (resultCode == Activity.RESULT_OK) {
                    doActivateProtection()
                }
            }
        }
    }

    private fun checkVpnAndActivate() {
        DnsFilterVpnService.prepareVpn(this)?.let { vpnIntent ->
            startActivityForResult(vpnIntent, 1002)
            return
        }
        doActivateProtection()
    }

    override fun onResume() {
        super.onResume()
        loadConfig()
    }

    override fun onDestroy() {
        binding = null
        super.onDestroy()
    }
}