package com.pornblocker.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.pornblocker.R
import com.pornblocker.databinding.ActivitySettingsBinding
import com.pornblocker.model.AppDatabase
import com.pornblocker.model.BlockConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    
    private var binding: ActivitySettingsBinding? = null
    private var currentConfig: BlockConfig? = null
    private var selectedAppPackage: String = ""
    private var selectedAppLabel: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        
        setupToolbar()
        loadConfig()
        setupListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding?.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        binding?.toolbar?.setNavigationOnClickListener { onBackPressed() }
    }

    private fun loadConfig() {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@SettingsActivity)
            currentConfig = db.blockConfigDao().getConfigSync() ?: BlockConfig()
            
            runOnUiThread {
                populateFields()
            }
        }
    }

    private fun populateFields() {
        currentConfig?.let { config ->
            binding?.wordsEditText?.setText(config.blockedWords)
            binding?.sitesEditText?.setText(config.blockedSites)
            binding?.redirectSwitch?.isChecked = config.isRedirectEnabled
            binding?.selectAppButton?.isEnabled = config.isRedirectEnabled
            
            if (config.redirectPackageName.isNotEmpty()) {
                selectedAppPackage = config.redirectPackageName
                selectedAppLabel = getAppLabel(config.redirectPackageName)
                binding?.selectedAppText?.text = selectedAppLabel
            } else {
                binding?.selectedAppText?.text = getString(R.string.redirect_app_disabled)
            }
        }
    }

    private fun setupListeners() {
        binding?.redirectSwitch?.setOnCheckedChangeListener { _, isChecked ->
            binding?.selectAppButton?.isEnabled = isChecked
            if (!isChecked) {
                binding?.selectedAppText?.text = getString(R.string.redirect_app_disabled)
                selectedAppPackage = ""
                selectedAppLabel = ""
            }
        }
        
        binding?.selectAppButton?.setOnClickListener { openAppPicker() }
        binding?.saveButton?.setOnClickListener { saveConfig() }
        binding?.resetButton?.setOnClickListener { showResetDialog() }
    }

    private fun openAppPicker() {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        val apps = pm.queryIntentActivities(intent, 0)
        
        val appNames = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val appPackages = apps.map { it.activityInfo.packageName }.toTypedArray()
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Seleccionar App de Redirección")
            .setSingleChoiceItems(appNames, -1) { dialog, which ->
                selectedAppPackage = appPackages[which]
                selectedAppLabel = appNames[which]
                binding?.selectedAppText?.text = selectedAppLabel
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun saveConfig() {
        val words = binding?.wordsEditText?.text.toString() ?: ""
        val sites = binding?.sitesEditText?.text.toString() ?: ""
        val redirectEnabled = binding?.redirectSwitch?.isChecked ?: false
        val redirectPackage = if (redirectEnabled) selectedAppPackage else ""
        
        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@SettingsActivity)
            val config = db.blockConfigDao().getConfigSync() ?: BlockConfig()
            val updated = config.copy(
                blockedWords = words,
                blockedSites = sites,
                redirectPackageName = redirectPackage,
                isRedirectEnabled = redirectEnabled,
                lastUpdated = System.currentTimeMillis()
            )
            db.blockConfigDao().updateConfig(updated)
            
            runOnUiThread {
                currentConfig = updated
                Toast.makeText(this@SettingsActivity, "Configuración guardada", Toast.LENGTH_SHORT).show()
                
                // Notificar a servicios para actualizar listas
                sendBroadcast(Intent("com.pornblocker.CONFIG_UPDATED"))
            }
        }
    }

    private fun showResetDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Restablecer Valores")
            .setMessage("Esto restaurará la lista negra predeterminada y desactivará la redirección. ¿Continuar?")
            .setPositiveButton("Restablecer") { _, _ ->
                resetToDefaults()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun resetToDefaults() {
        lifecycleScope.launch(Dispatchers.IO) {
            val repo = com.pornblocker.model.ConfigRepositoryFactory.create(this@SettingsActivity)
            repo.resetToDefaults()
            val db = AppDatabase.getDatabase(this@SettingsActivity)
            val defaults = db.blockConfigDao().getConfigSync()
            
            runOnUiThread {
                currentConfig = defaults
                populateFields()
                Toast.makeText(this@SettingsActivity, "Valores restablecidos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getAppLabel(packageName: String): String {
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString()
        } catch (e: Exception) {
            packageName
        }
    }

    override fun onDestroy() {
        binding = null
        super.onDestroy()
    }
}