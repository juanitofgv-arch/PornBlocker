package com.pornblocker.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.pornblocker.R
import com.pornblocker.model.AppDatabase
import com.pornblocker.model.BlockConfig
import com.pornblocker.root.RootHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MonitoringForegroundService : Service() {
    
    private val TAG = "MonitoringService"
    private val NOTIFICATION_ID = 1001
    private val CHANNEL_ID = "monitoring_channel"
    
    private var isRunning = false
    private val scope = CoroutineScope(Dispatchers.IO)
    private var currentConfig: BlockConfig? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        loadConfig()
    }

    private fun loadConfig() {
        scope.launch {
            val db = AppDatabase.getDatabase(this@MonitoringForegroundService)
            currentConfig = db.blockConfigDao().getConfigSync()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.foreground_service_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.foreground_service_description)
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            isRunning = true
            startForegroundMonitoring()
        }
        return START_STICKY
    }

    private fun startForegroundMonitoring() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        
        scope.launch {
            monitoringLoop()
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, com.pornblocker.ui.MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, 
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .build()
    }

    private suspend fun monitoringLoop() {
        while (isRunning) {
            try {
                // Verificar configuración actualizada
                val db = AppDatabase.getDatabase(this@MonitoringForegroundService)
                currentConfig = db.blockConfigDao().getConfigSync()
                
                // Si la protección no está activa, detener el servicio
                if (currentConfig?.isProtectionActive != true) {
                    stopSelf()
                    break
                }
                
                // Verificar que los servicios críticos estén corriendo
                checkCriticalServices()
                
                // Verificar navegadores en primer plano y su contenido
                checkForegroundBrowsers()
                
                // Actualizar dominios bloqueados en VPN
                updateVpnBlocklist()
                
            } catch (e: Exception) {
                Log.e(TAG, "Error in monitoring loop", e)
            }
            
            delay(5000) // Verificar cada 5 segundos
        }
    }

    private fun checkCriticalServices() {
        // Verificar que el servicio de accesibilidad esté habilitado
        // Verificar que la VPN esté activa
        // Si no, intentar reiniciarlos
    }

    private fun checkForegroundBrowsers() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val browserPackages = RootHelper.getInstalledBrowserPackages(this)
        
        // En Android 10+, obtener app en primer plano requiere permisos especiales
        // Usamos UsageStats o Accessibility Service para esto
    }

    private fun updateVpnBlocklist() {
        // Enviar broadcast al VPN service para actualizar lista
        currentConfig?.let { config ->
            val intent = Intent("com.pornblocker.UPDATE_VPN_BLOCKLIST")
            // intent.putExtra("config", config)
            sendBroadcast(intent)
        }
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = null

    companion object {
        fun startService(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java)
            context.stopService(intent)
        }
    }
}