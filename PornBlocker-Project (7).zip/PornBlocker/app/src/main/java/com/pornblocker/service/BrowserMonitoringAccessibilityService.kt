package com.pornblocker.service

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import com.pornblocker.model.AppDatabase
import com.pornblocker.model.BlockConfig
import com.pornblocker.model.DetectionLog
import com.pornblocker.root.RootHelper
import com.pornblocker.util.ContentDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class BrowserMonitoringAccessibilityService : AccessibilityService() {
    
    private val TAG = "BrowserMonitorService"
    private val scope = CoroutineScope(Dispatchers.IO)
    private var currentConfig: BlockConfig? = null
    private val knownBrowserPackages = mutableSetOf<String>()
    private val handler = Handler(Looper.getMainLooper())
    private var lastDetectionTime = 0L
    private val detectionCooldown = 2000L // 2 segundos entre detecciones

    override fun onCreate() {
        super.onCreate()
        loadConfig()
        loadBrowserPackages()
    }

    private fun loadConfig() {
        scope.launch {
            val db = AppDatabase.getDatabase(this@BrowserMonitoringAccessibilityService)
            currentConfig = db.blockConfigDao().getConfigSync()
            Log.d(TAG, "Config loaded: ${currentConfig?.isProtectionActive}")
        }
    }

    private fun loadBrowserPackages() {
        knownBrowserPackages.clear()
        knownBrowserPackages.addAll(RootHelper.getInstalledBrowserPackages(this))
        Log.d(TAG, "Known browsers: $knownBrowserPackages")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        
        // Solo procesar si la protección está activa
        if (currentConfig?.isProtectionActive != true) return
        
        // Cooldown para evitar detecciones múltiples
        val now = System.currentTimeMillis()
        if (now - lastDetectionTime < detectionCooldown) return
        
        val packageName = event.packageName?.toString() ?: return
        
        // Verificar si es un navegador conocido
        if (!isBrowserPackage(packageName)) return
        
        // Procesar según tipo de evento
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                checkWindowContent(event)
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                checkTextChange(event)
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                checkClickedView(event)
            }
        }
    }

    private fun isBrowserPackage(packageName: String): Boolean {
        return knownBrowserPackages.contains(packageName) || 
               packageName.contains("browser", ignoreCase = true) ||
               packageName.contains("chrome", ignoreCase = true) ||
               packageName.contains("firefox", ignoreCase = true)
    }

    private fun checkWindowContent(event: AccessibilityEvent) {
        val source = event.source ?: return
        try {
            val text = extractAllText(source)
            if (text.isNotEmpty()) {
                analyzeContent(text, event.packageName.toString(), "window_content")
            }
            
            // Verificar URL en la barra de direcciones
            val urls = findUrlsInView(source)
            for (url in urls) {
                analyzeUrl(url, event.packageName.toString())
            }
        } finally {
            source.recycle()
        }
    }

    private fun checkTextChange(event: AccessibilityEvent) {
        val text = event.text?.joinToString("") ?: ""
        if (text.length > 3) {
            analyzeContent(text, event.packageName.toString(), "text_change")
        }
    }

    private fun checkClickedView(event: AccessibilityEvent) {
        val source = event.source ?: return
        try {
            val text = extractAllText(source)
            if (text.isNotEmpty()) {
                analyzeContent(text, event.packageName.toString(), "click")
            }
        } finally {
            source.recycle()
        }
    }

    private fun extractAllText(node: AccessibilityNodeInfo): String {
        val builder = StringBuilder()
        extractTextRecursive(node, builder)
        return builder.toString()
    }

    private fun extractTextRecursive(node: AccessibilityNodeInfo, builder: StringBuilder) {
        if (node.text != null && node.text.isNotEmpty()) {
            builder.append(node.text).append(" ")
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            child?.let {
                extractTextRecursive(it, builder)
                it.recycle()
            }
        }
    }

    private fun findUrlsInView(node: AccessibilityNodeInfo): List<String> {
        val urls = mutableListOf<String>()
        findUrlsRecursive(node, urls)
        return urls
    }

    private fun findUrlsRecursive(node: AccessibilityNodeInfo, urls: MutableList<String>) {
        // Buscar en vistas de texto (barra de direcciones, resultados de búsqueda, etc.)
        if (node.className != null) {
            val className = node.className.toString().lowercase()
            if (className.contains("edittext") || className.contains("textview") || 
                className.contains("url") || className.contains("address") ||
                className.contains("search") || className.contains("omnibox")) {
                node.text?.let { text ->
                    if (text.isNotEmpty()) {
                        val extracted = ContentDetector.extractUrls(text.toString())
                        urls.addAll(extracted)
                    }
                }
            }
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            child?.let {
                findUrlsRecursive(it, urls)
                it.recycle()
            }
        }
    }

    private fun analyzeContent(text: String, browserPackage: String, trigger: String) {
        val (hasBlocked, matchedWord) = ContentDetector.containsBlockedWords(text, currentConfig!!)
        if (hasBlocked) {
            lastDetectionTime = System.currentTimeMillis()
            Log.w(TAG, "Blocked word detected: $matchedWord in $browserPackage")
            triggerBlockAction(browserPackage, "Palabra prohibida: $matchedWord", trigger)
        }
    }

    private fun analyzeUrl(url: String, browserPackage: String) {
        val (isBlocked, matchedSite) = ContentDetector.isBlockedSite(url, currentConfig!!)
        if (isBlocked) {
            lastDetectionTime = System.currentTimeMillis()
            Log.w(TAG, "Blocked site detected: $matchedSite in $browserPackage")
            triggerBlockAction(browserPackage, "Sitio prohibido: $matchedSite", "url_navigation")
        }
    }

    private fun triggerBlockAction(browserPackage: String, reason: String, triggerType: String) {
        // Ejecutar en background para no bloquear el hilo de accesibilidad
        scope.launch {
            performBlockActions(browserPackage, reason, triggerType)
        }
    }

    private suspend fun performBlockActions(browserPackage: String, reason: String, triggerType: String) {
        val db = AppDatabase.getDatabase(this@BrowserMonitoringAccessibilityService)
        var wasRedirected = false
        
        try {
            // 1. Cerrar el navegador
            val killed = RootHelper.killApp(browserPackage)
            Log.d(TAG, "Kill browser $browserPackage: $killed")
            
            // 2. Borrar caché y datos
            val cleared = RootHelper.clearAppCacheAndData(browserPackage)
            Log.d(TAG, "Clear cache $browserPackage: $cleared")
            
            // 3. Abrir app de redirección si está configurada
            currentConfig?.let { config ->
                if (config.isRedirectEnabled && config.redirectPackageName.isNotEmpty()) {
                    wasRedirected = openRedirectApp(config.redirectPackageName)
                }
            }
            
            // 4. Registrar en log
            db.blockConfigDao().logDetection(browserPackage, reason, "kill_clear_redirect", wasRedirected)
            
            // 5. Mostrar notificación al usuario
            showBlockNotification(reason)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error performing block actions", e)
        }
    }

    private fun openRedirectApp(packageName: String): Boolean {
        return try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening redirect app", e)
            false
        }
    }

    private fun showBlockNotification(reason: String) {
        handler.post {
            val notification = NotificationCompat.Builder(this, "block_alert_channel")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Contenido Bloqueado")
                .setContentText("Se detectó: $reason. El navegador ha sido cerrado y su caché borrada.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ERROR)
                .setAutoCancel(true)
                .build()
            
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.notify("block_alert", System.currentTimeMillis().toInt(), notification)
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        fun isServiceEnabled(context: Context): Boolean {
            val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
            val enabledServices = accessibilityManager.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_GENERIC)
            return enabledServices.any { it.id.contains("BrowserMonitoringAccessibilityService") }
        }
    }
}