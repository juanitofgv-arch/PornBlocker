package com.pornblocker.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.pornblocker.R
import com.pornblocker.model.AppDatabase
import com.pornblocker.model.BlockConfig
import com.pornblocker.service.MonitoringForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AdminReceiver : DeviceAdminReceiver() {
    
    companion object {
        private const val TAG = "AdminReceiver"
    }

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        context.let {
            Log.d(TAG, "Device admin enabled")
            Toast.makeText(it, "Protección activada - No se puede desactivar", Toast.LENGTH_LONG).show()
            
            // Iniciar servicios de monitoreo
            MonitoringForegroundService.startService(it)
            
            // Marcar protección como activa en BD
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(it)
                val config = db.blockConfigDao().getConfigSync() ?: BlockConfig()
                val updated = config.copy(isProtectionActive = true)
                db.blockConfigDao().updateConfig(updated)
            }
        }
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return context.getString(R.string.admin_description) 
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        context.let {
            Log.d(TAG, "Device admin disabled")
            Toast.makeText(it, "Protección desactivada", Toast.LENGTH_LONG).show()
            
            // Detener servicios
            MonitoringForegroundService.stopService(it)
            
            // Marcar protección como inactiva
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(it)
                val config = db.blockConfigDao().getConfigSync() ?: BlockConfig()
                val updated = config.copy(isProtectionActive = false)
                db.blockConfigDao().updateConfig(updated)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        // Manejar eventos adicionales si es necesario
    }
}