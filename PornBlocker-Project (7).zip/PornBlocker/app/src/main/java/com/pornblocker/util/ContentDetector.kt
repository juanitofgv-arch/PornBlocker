package com.pornblocker.util

import com.pornblocker.model.BlockConfig

object ContentDetector {
    
    /** Verifica si un texto contiene palabras de la lista negra */
    fun containsBlockedWords(text: String, config: BlockConfig): Pair<Boolean, String> {
        val words = config.blockedWords
            .split("\n")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
        
        val lowerText = text.lowercase()
        
        for (word in words) {
            if (lowerText.contains(word)) {
                return Pair(true, word)
            }
        }
        return Pair(false, "")
    }
    
    /** Verifica si una URL pertenece a un sitio bloqueado */
    fun isBlockedSite(url: String, config: BlockConfig): Pair<Boolean, String> {
        val sites = config.blockedSites
            .split("\n")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
        
        val lowerUrl = url.lowercase()
        
        for (site in sites) {
            if (lowerUrl.contains(site)) {
                return Pair(true, site)
            }
        }
        return Pair(false, "")
    }
    
    /** Extrae URLs de un texto */
    fun extractUrls(text: String): List<String> {
        val urlRegex = """(https?://[^\s]+|www\.[^\s]+|[a-zA-Z0-9.-]+\.(com|net|org|xxx|porn|sex|adult|cam|tube|site))"""
        val pattern = urlRegex.toRegex()
        return pattern.findAll(text).map { it.value }.distinct().toList()
    }
}